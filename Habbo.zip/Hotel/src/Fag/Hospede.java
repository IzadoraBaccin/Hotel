package Fag;
import java.util.ArrayList;

public class Hospede {
 String nome;
 ArrayList<Reserva> reservas;

 public Hospede(String nome) {
     this.nome = nome;
     this.reservas = new ArrayList<>();
 }

 public void adicionarReserva(Reserva reserva) {
     reservas.add(reserva);
 }

 public ArrayList<Reserva> getReservas() {
     return reservas;
 }

 @Override
 public String toString() {
     return "Hóspede: " + nome;
 }
}

