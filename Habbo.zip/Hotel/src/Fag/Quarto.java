package Fag;

 public class Quarto {
 int numero;
 String tipo;
 double precoDiario;
 boolean disponivel;

 public Quarto(int numero, String tipo, double precoDiario) {
     this.numero = numero;
     this.tipo = tipo;
     this.precoDiario = precoDiario;
     this.disponivel = true;
 }

 public void ocupar() {
     this.disponivel = false;
 }

 public void liberar() {
     this.disponivel = true;
 }

 public boolean isDisponivel() {
     return disponivel;
 }

 @Override
 public String toString() {
     return "Quarto " + numero + " - Tipo: " + tipo + " - Preço: " + precoDiario + " - Disponível: " + (disponivel ? "Sim" : "Não");
 }
}

