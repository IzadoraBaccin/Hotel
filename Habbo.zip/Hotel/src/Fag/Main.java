package Fag;
import java.util.Scanner;

public class Main {
 public static void main(String[] args) {
     Hotel hotel = new Hotel();
     Scanner scanner = new Scanner(System.in);
     int opcao;

     do {
         System.out.println("Menu:");
         System.out.println("1. Adicionar Quarto");
         System.out.println("2. Registrar Reserva");
         System.out.println("3. Registrar Check-out");
         System.out.println("4. Relatório de Ocupação");
         System.out.println("5. Relatório de Reservas");
         System.out.println("0. Sair");
         System.out.print("Escolha uma opção: ");
         opcao = scanner.nextInt();
         scanner.nextLine(); 

         switch (opcao) {
             case 1:
                 System.out.print("Número do Quarto: ");
                 int numero = scanner.nextInt();
                 scanner.nextLine();
                 System.out.print("Tipo do Quarto (solteiro, casal, suite): ");
                 String tipo = scanner.nextLine();
                 System.out.print("Preço Diário: ");
                 double preco = scanner.nextDouble();
                 Quarto quarto = new Quarto(numero, tipo, preco);
                 hotel.adicionarQuarto(quarto);
                 System.out.println("Quarto adicionado com sucesso!");
                 break;

             case 2:
                 System.out.print("Nome do Hóspede: ");
                 String nomeHospede = scanner.nextLine();
                 System.out.print("Data de Check-in (dd/MM/yyyy): ");
                 String dataCheckIn = scanner.nextLine();
                 System.out.print("Data de Check-out (dd/MM/yyyy): ");
                 String dataCheckOut = scanner.nextLine();
                 System.out.print("Número de Quartos Reservados: ");
                 int numeroQuartos = scanner.nextInt();
                 scanner.nextLine(); 
                 System.out.print("Tipo de Quarto Reservado: ");
                 String tipoQuarto = scanner.nextLine();
                 hotel.registrarReserva(nomeHospede, dataCheckIn, dataCheckOut, numeroQuartos, tipoQuarto);
                 break;

             case 3:
                 System.out.print("Nome do Hóspede para Check-out: ");
                 String nomeCheckOut = scanner.nextLine();
                 hotel.registrarCheckOut(nomeCheckOut);
                 break;

             case 4:
                 hotel.relatorioOcupacao();
                 break;

             case 5:
                 hotel.relatorioReservas();
                 break;

             case 0:
                 System.out.println("Saindo do sistema.");
                 break;

             default:
                 System.out.println("Opção inválida. Tente novamente.");
                 break;
         }
     } while (opcao != 0);
     
     scanner.close();
 }
}

