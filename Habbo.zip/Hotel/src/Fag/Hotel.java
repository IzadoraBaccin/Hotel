package Fag;
import java.util.ArrayList;

public class Hotel {
 ArrayList<Quarto> quartos;
 ArrayList<Hospede> hospedes;

 public Hotel() {
     quartos = new ArrayList<>();
     hospedes = new ArrayList<>();
 }

 public void adicionarQuarto(Quarto quarto) {
     quartos.add(quarto);
 }

 public void registrarReserva(String nomeHospede, String dataCheckIn, String dataCheckOut, int numeroQuartos, String tipoQuarto) {
     for (Quarto quarto : quartos) {
         if (quarto.tipo.equals(tipoQuarto) && quarto.isDisponivel() && numeroQuartos > 0) {
             quarto.ocupar();
             Reserva reserva = new Reserva(nomeHospede, dataCheckIn, dataCheckOut, numeroQuartos, tipoQuarto);
             Hospede hospede = new Hospede(nomeHospede);
             hospede.adicionarReserva(reserva);
             hospedes.add(hospede);
             System.out.println("Reserva registrada com sucesso!");
             return;
         }
     }
     System.out.println("Não há quartos disponíveis do tipo solicitado.");
 }

 public void registrarCheckOut(String nomeHospede) {
     for (Hospede hospede : hospedes) {
         if (hospede.nome.equals(nomeHospede)) {
             for (Reserva reserva : hospede.getReservas()) {
                 for (Quarto quarto : quartos) {
                     if (quarto.tipo.equals(reserva.tipoQuarto) && !quarto.isDisponivel()) {
                         quarto.liberar();
                         System.out.println("Check-out realizado com sucesso!");
                         return;
                     }
                 }
             }
         }
     }
     System.out.println("Hóspede não encontrado ou nenhum quarto reservado.");
 }

 public void relatorioOcupacao() {
     System.out.println("Relatório de Ocupação:");
     for (Quarto quarto : quartos) {
         if (!quarto.isDisponivel()) {
             System.out.println(quarto);
         }
     }
 }

 public void relatorioReservas() {
     System.out.println("Histórico de Reservas:");
     for (Hospede hospede : hospedes) {
         for (Reserva reserva : hospede.getReservas()) {
             System.out.println(reserva);
         }
     }
 }
}

